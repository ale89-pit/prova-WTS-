package com.tecninf.commesse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommesseApplicationTests {

	@Test
	void contextLoads() {
	}

}
