package it.tecninf.risorse.risorse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RisorseApplication {

	public static void main(String[] args) {
		SpringApplication.run(RisorseApplication.class, args);
	}

}
