package it.tecninf.risorse.risorse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RisorseApplicationTests {

	@Test
	void contextLoads() {
	}

}
